THE VYBE MVP

This is the current front-end MVP/prototype.
It is NOT yet a real multi-user service: accounts, live chat, leaderboard and admin permissions still need a secure backend.
For public launch, publish index.html through a host such as GitHub Pages, then add a real backend/auth/database before inviting players.
